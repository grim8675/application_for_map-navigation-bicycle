package com.example.whealingservice;

public class Category {
    private String animalName;

    public Category(String animalName) {
        this.animalName = animalName;
    }

    public String getAnimalName() {
        return this.animalName;
    }
}
