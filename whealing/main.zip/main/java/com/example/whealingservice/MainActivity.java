package com.example.whealingservice;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import com.example.whealingservice.Page.BicyclePage;
import com.example.whealingservice.Page.HomePage;
import com.example.whealingservice.Page.MapPage;
import com.example.whealingservice.Page.PlanPage;
import com.example.whealingservice.Page.SettingPage;
import com.google.android.material.bottomnavigation.BottomNavigationMenuView;
import com.google.android.material.bottomnavigation.BottomNavigationView;


import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.NonNull;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapterCallback, BottomSheetDialog.BottomSheetListener{

    HomePage homePage = new HomePage();
    BicyclePage bicyclePage = new BicyclePage();
    MapPage mapPage;
    PlanPage planPage = new PlanPage();
    SettingPage settingPage = new SettingPage();

    MenuItem searchItem;
    SearchView searchView;
    BottomNavigationView navView;
    BottomNavigationMenuView menuView;

    private EditText editText;
    private Runnable workRunnable;
    private RecyclerView recyclerView;
    private RecyclerViewAdapter recyclerViewAdapter;
    private Handler handler = new Handler(Looper.getMainLooper());
    private final long DELAY = 500;
    InputMethodManager imm;

    ////////////////////////////navi search 부분//////////////////////////////////
    private SearchView start_searchview;
    private SearchView middle_searchview1;
    private SearchView middle_searchview2;
    private SearchView middle_searchview3;
    private SearchView middle_searchview4;
    private SearchView middle_searchview5;
    private SearchView finish_searchview;
    private View naviAction;
    private ImageButton cancel_navigation;
    private ImageButton middle_add1;
    private ImageButton middle_remove2;
    private ImageButton middle_remove3;
    private ImageButton middle_remove4;
    private ImageButton middle_remove5;
    private LinearLayout middle1;
    private LinearLayout middle2;
    private LinearLayout middle3;
    private LinearLayout middle4;


    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        start_searchview = (SearchView) findViewById(R.id.start_search);
        middle_searchview1 = (SearchView) findViewById(R.id.middle_search1);
        middle_searchview2 = (SearchView) findViewById(R.id.middle_search2);
        middle_searchview3 = (SearchView) findViewById(R.id.middle_search3);
        middle_searchview4 = (SearchView) findViewById(R.id.middle_search4);
        middle_searchview5 = (SearchView) findViewById(R.id.middle_search5);
        finish_searchview = (SearchView) findViewById(R.id.finish_search);

        middle_add1 = (ImageButton) findViewById(R.id.middle_add1);
        middle_remove2 = (ImageButton) findViewById(R.id.remove1);
        middle_remove3 = (ImageButton) findViewById(R.id.remove2);
        middle_remove4 = (ImageButton) findViewById(R.id.remove3);
        middle_remove5 = (ImageButton) findViewById(R.id.remove4);

        middle1 = (LinearLayout) findViewById(R.id.middle_linear1);
        middle2 = (LinearLayout) findViewById(R.id.middle_linear2);
        middle3 = (LinearLayout) findViewById(R.id.middle_linear3);
        middle4 = (LinearLayout) findViewById(R.id.middle_linear4);

        setSearchView();

        editText = (EditText)findViewById(R.id.edt_search);
        recyclerView = (RecyclerView)findViewById(R.id.rl_listview);
        recyclerViewAdapter = new RecyclerViewAdapter();

        mapPage = new MapPage();

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(recyclerViewAdapter);

        recyclerViewAdapter.setCallback(this);

        navView = findViewById(R.id.nav_view);
        menuView = (BottomNavigationMenuView) navView.getChildAt(0);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                switch (item.getItemId()) {
                    case R.id.navigation_home:
                        transaction.replace(R.id.frame_layout, homePage).commitAllowingStateLoss();
                        return true;

                    case R.id.navigation_bicycle:
                        transaction.replace(R.id.frame_layout, bicyclePage).commitAllowingStateLoss();
                        return true;

                    case R.id.navigation_map:
                        transaction.replace(R.id.frame_layout, mapPage).commitAllowingStateLoss();
                        return true;

                    case R.id.navigation_plan:
                        transaction.replace(R.id.frame_layout, planPage).commitAllowingStateLoss();
                        return true;

                    case R.id.navigation_setting:
                        transaction.replace(R.id.frame_layout, settingPage).commitAllowingStateLoss();
                        return true;
                }
                return false;
            }
        });
    }

    private void setSearchView () {

        int id = start_searchview.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView = (TextView) start_searchview.findViewById(id);
        textView.setTextColor(Color.BLACK);
        start_searchview.onActionViewExpanded();
        start_searchview.setIconified(true);

        start_searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                start_searchview.clearFocus();
//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });

        start_searchview.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });

        int id1 = middle_searchview1.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView1 = (TextView) middle_searchview1.findViewById(id1);
        textView1.setTextColor(Color.BLACK);

        middle_searchview1.onActionViewExpanded();
        middle_searchview1.setIconified(true);

        middle_searchview1.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                middle_searchview1.clearFocus();

//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });

        middle_searchview1.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);
                Log.w("Close listener", "" + recyclerView.getVisibility());

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });

        int id2 = middle_searchview2.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView2 = (TextView) middle_searchview2.findViewById(id2);
        textView2.setTextColor(Color.BLACK);

        middle_searchview2.onActionViewExpanded();
        middle_searchview2.setIconified(true);

        middle_searchview2.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                middle_searchview2.clearFocus();

//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });

        middle_searchview2.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });
        int id3 = middle_searchview3.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView3 = (TextView) middle_searchview3.findViewById(id3);
        textView3.setTextColor(Color.BLACK);

        middle_searchview3.onActionViewExpanded();
        middle_searchview3.setIconified(true);

        middle_searchview3.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                middle_searchview3.clearFocus();

//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });

        middle_searchview3.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });

        int id4 = middle_searchview4.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView4 = (TextView) middle_searchview4.findViewById(id4);
        textView4.setTextColor(Color.BLACK);

        middle_searchview4.onActionViewExpanded();
        middle_searchview4.setIconified(true);

        middle_searchview4.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                middle_searchview4.clearFocus();

//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });

        middle_searchview4.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });

        int id5 = middle_searchview5.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView5 = (TextView) middle_searchview5.findViewById(id5);
        textView5.setTextColor(Color.BLACK);

        middle_searchview5.onActionViewExpanded();
        middle_searchview5.setIconified(true);

        middle_searchview5.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                middle_searchview5.clearFocus();

//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });

        middle_searchview5.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });

        int id6 = finish_searchview.getContext()
                .getResources()
                .getIdentifier("android:id/search_src_text", null, null);
        TextView textView6 = (TextView) finish_searchview.findViewById(id6);
        textView6.setTextColor(Color.BLACK);

        finish_searchview.onActionViewExpanded();
        finish_searchview.setIconified(true);

        finish_searchview.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                keyboardHide();
                finish_searchview.clearFocus();

//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {

                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(s);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (s.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return false;
            }
        });
        finish_searchview.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });

        middle_add1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.middle_add1) {
                    if (middle1.getVisibility() == View.GONE)
                        middle1.setVisibility(View.VISIBLE);
                    else if (middle2.getVisibility() == View.GONE)
                        middle2.setVisibility(View.VISIBLE);
                    else if (middle3.getVisibility() == View.GONE)
                        middle3.setVisibility(View.VISIBLE);
                    else if (middle4.getVisibility() == View.GONE)
                        middle4.setVisibility(View.VISIBLE);
                    else
                        Toast.makeText(MainActivity.this, "경유지 추가는 최대 다섯개까지 지원합니다.", Toast.LENGTH_LONG).show();
                }
            }
        });

        middle_remove2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                middle1.setVisibility(View.GONE);
            }
        });
        middle_remove3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                middle2.setVisibility(View.GONE);
            }
        });
        middle_remove4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                middle3.setVisibility(View.GONE);
            }
        });
        middle_remove5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                middle4.setVisibility(View.GONE);
            }
        });

        cancel_navigation = (ImageButton) findViewById(R.id.cancel_navi);
        cancel_navigation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getId() == R.id.cancel_navi) {
                    naviAction.setVisibility(View.GONE);
                    keyboardHide();
                }
            }
        });

    }

    public void keyboardHide () {
        imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        imm.hideSoftInputFromWindow(start_searchview.getWindowToken(), 0);
        imm.hideSoftInputFromWindow(middle_searchview1.getWindowToken(), 0);
        imm.hideSoftInputFromWindow(finish_searchview.getWindowToken(), 0);
        start_searchview.clearFocus();
        middle_searchview1.clearFocus();
        finish_searchview.clearFocus();

    }

    @Override
    public void SelectSearchItem(int position) {
        navView.getMenu().findItem(R.id.navigation_map).setChecked(true);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout, MapPage.newInstance(
                recyclerViewAdapter.getItemTitle(position),
                recyclerViewAdapter.getItemLat(position),
                recyclerViewAdapter.getItemLon(position),
                recyclerViewAdapter.getItemCategory(position),
                recyclerViewAdapter.getItemTime(position),
                recyclerViewAdapter.getItemTelNo(position)
        )).commitAllowingStateLoss();

        keyboardHide();
        searchView.onActionViewCollapsed();
        recyclerView.setVisibility(View.GONE);

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//            recyclerView.setZ(0);
//        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.bar, menu);

        searchItem = menu.findItem(R.id.action_search);
        searchView = (SearchView) searchItem.getActionView();
        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setQueryHint("검색어를 입력해주세요.");

        androidx.appcompat.widget.SearchView.SearchAutoComplete searchAutoComplete = (androidx.appcompat.widget.SearchView.SearchAutoComplete) searchView.findViewById(R.id.search_src_text);

//        MenuItemCompat.OnActionExpandListener expandListener = new MenuItemCompat.OnActionExpandListener() {
//            @Override
//            public boolean onMenuItemActionExpand(MenuItem item){
//                Toast.makeText(MainActivity.this, "확장", Toast.LENGTH_SHORT).show();
//                return true;
//            }
//            @Override
//            public boolean onMenuItemActionCollapse(MenuItem item){
//                Toast.makeText(MainActivity.this, "축소", Toast.LENGTH_SHORT).show();
//                return true;
//            }
//        };
//
//        MenuItemCompat.setOnActionExpandListener(searchItem, expandListener);

        // SearchView 검색어 입력/검색 이벤트 처리
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                recyclerView.setVisibility(View.GONE);
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(0);
//                }
                return false;
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                keyboardHide();
//                recyclerView.setVisibility(View.VISIBLE);

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
//                    recyclerView.setZ(1);
//                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(final String newText) {
//
                handler.removeCallbacks(workRunnable);
                workRunnable = new Runnable() {
                    @Override
                    public void run() {
                        recyclerViewAdapter.filter(newText);
                    }
                };
                handler.postDelayed(workRunnable, DELAY);
                if (newText.length() > 1)
                    recyclerView.setVisibility(View.VISIBLE);
                else
                    recyclerView.setVisibility(View.GONE);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP ) {
                    recyclerView.setZ(1);
                }
                return true;
            }
        });
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.action_search) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onButtonClicked(String text, String title, double lat, double lon) {
        naviAction = (View) findViewById(R.id.navi_action);
        naviAction.setVisibility(View.VISIBLE);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            naviAction.setZ(5);
        }
        if (text.equals("START")) {
            start_searchview.setQuery(title, false);
            start_searchview.clearFocus();
        }
        if (text.equals("MIDDLE1")) {
            middle_searchview1.setQuery(title, false);
            middle_searchview1.clearFocus();
            if (start_searchview.getQuery() == null) {
                start_searchview.setQuery("내 위치", false);
            }
        }
        if (text.equals("FINISH")) {
            finish_searchview.setQuery(title, false);
            finish_searchview.clearFocus();
            if (start_searchview.getQuery() == null) {
                start_searchview.setQuery("내 위치", false);
            }
        }
        recyclerView.setVisibility(View.GONE);

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_layout, MapPage.newInstance( text, lat, lon, text, null , null)).commitAllowingStateLoss();
    }
}
