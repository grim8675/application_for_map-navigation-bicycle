package com.example.whealingservice;

public interface CustomInterface {
    public void callbackMethod(String date);
}
