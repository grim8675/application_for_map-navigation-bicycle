package com.example.whealingservice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentTransaction;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.whealingservice.Page.MapPage;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

public class BottomSheetDialog extends BottomSheetDialogFragment implements View.OnClickListener {

    private static final String SOME_INTENT_FILTER_NAME = null;
    private LinearLayout linearLayout;
    private TextView title;
    private TextView category;
    private TextView addr;
    private TextView time;
    private TextView telNo;
    private ImageView addr_img;
    private ImageView time_img;
    private ImageView tel_img;
    private Button start_point;
    private Button middle_point;
    private Button final_point;
    private String m_title = null;
    private String m_category;
    private String m_addr;
    private String m_addr1;
    private String m_time;
    private String m_telNo;
    private double mLat;
    private double mLon;
    private String navi_mode = null;
    private int clicked_button = 0;
    private LinearLayout navi_layout;
    private Context mContext;
    private BottomSheetListener mListener;


    public static BottomSheetDialog getInstance(String title, String category, String addr1, String addr2, String time, String telNo, double lat, double lon) {

        BottomSheetDialog fragment = new BottomSheetDialog();
        Bundle args = new Bundle();
        args.putString("Title", title);
        args.putString("Category", category);
        args.putString("Address", addr1);
        args.putString("new_Address", addr2);
        args.putString("Time", time);
        args.putString("TelNum", telNo);
        args.putDouble("Lat", lat);
        args.putDouble("Lon", lon);

        fragment.setArguments(args);

        return fragment;
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        mContext = getActivity();
        View view = inflater.inflate(R.layout.detail_view, container,false);
        linearLayout = (LinearLayout) view.findViewById(R.id.detail_linear);
        title = (TextView) view.findViewById(R.id.detail_title);
        category = (TextView) view.findViewById(R.id.detail_category);
        addr = (TextView) view.findViewById(R.id.detail_addr);
        time = (TextView) view.findViewById(R.id.detail_time);
        telNo = (TextView) view.findViewById(R.id.detail_tel);

        addr_img = (ImageView) view.findViewById(R.id.addr_img);
        time_img = (ImageView) view.findViewById(R.id.time_img);
        tel_img = (ImageView) view.findViewById(R.id.tel_img);

        start_point = (Button)view.findViewById(R.id.start_button);
        middle_point = (Button)view.findViewById(R.id.middle_button);
        final_point = (Button)view.findViewById(R.id.finish_button);

        navi_layout = (LinearLayout) view.findViewById(R.id.navi_layout);

        Log.w("arg Dialog", "" + getArguments());

        if(getArguments() != null) {
            m_title = getArguments().getString("Title");
            m_category = getArguments().getString("Category");
            m_addr = getArguments().getString("Address");
            m_addr1 = getArguments().getString("new_Address");
            m_time = getArguments().getString("Time");
            m_telNo = getArguments().getString("TelNum");
            mLat = getArguments().getDouble("Lat");
            mLon = getArguments().getDouble("Lon");

            setTextView(m_title, m_category, m_addr, m_addr1, m_time, m_telNo);
        }

        if(m_addr != null || m_addr == "") {
            addr_img.setVisibility(View.VISIBLE);
        }
        if(m_time != null || m_time == "") {
            time_img.setVisibility(View.VISIBLE);
        }
        if(m_telNo != null || m_telNo == "") {
            tel_img.setVisibility(View.VISIBLE);
        }
        start_point.setOnClickListener(this);
        middle_point.setOnClickListener(this);
        final_point.setOnClickListener(this);

        return view;
    }

    public void setTextView (String title,  String category, String addr, String addr1, String time, String telNo) {
        this.title.setText(title);
        this.category.setText(category);
        this.addr.setText(String.format("(구) %s\n(신) %s", addr, addr1));
        this.time.setText(time);
        this.telNo.setText(telNo);
    }

    @Override
    public void onClick(View view) {
        // 버튼 클릭 이벤트
        switch (view.getId()){
            case R.id.start_button:
//                if (mListener != null)
                mListener.onButtonClicked("START", m_title, mLat, mLon);
                dismiss();
                break;
            case R.id.middle_button:
//                Toast.makeText(getContext(),"Email",Toast.LENGTH_SHORT).show();
                mListener.onButtonClicked("MIDDLE1", m_title, mLat, mLon);
                dismiss();
                break;
            case R.id.finish_button:
//                Toast.makeText(getContext(),"Cloud",Toast.LENGTH_SHORT).show();
                mListener.onButtonClicked("FINISH", m_title, mLat, mLon);
                dismiss();
                break;
        }
        dismiss();
    }

    public interface BottomSheetListener {
        void onButtonClicked(String text, String title, double lat, double lon);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof BottomSheetListener) {
            mListener = (BottomSheetListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement FragmentAListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }
}
