package com.example.whealingservice.Page;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.example.whealingservice.BottomSheetDialog;
import com.example.whealingservice.Category;
import com.example.whealingservice.MapPoint;
import com.example.whealingservice.MarkerCotegory;
import com.example.whealingservice.Navigation.NaviSearchList;
import com.example.whealingservice.PermissionManager;
import com.example.whealingservice.R;
import com.skt.Tmap.TMapAddressInfo;
import com.skt.Tmap.TMapData;
import com.skt.Tmap.TMapGpsManager;
import com.skt.Tmap.TMapMarkerItem;
import com.skt.Tmap.TMapPoint;
import com.skt.Tmap.TMapView;

import java.util.ArrayList;
import java.util.Objects;

public class MapPage extends Fragment implements TMapGpsManager.onLocationChangedCallback {

    private Context mContext = null;
    private boolean m_bTrackingMode = true;
    PermissionManager permissionManager = null; // 권한요청 관리자

    private TMapGpsManager tmapgps = null;
    private TMapView tmapview = null;
    private static String mApiKey = "e2a8e309-be72-4e1e-941f-0ef0b77e4317";
    private static int mMarkerID;

    private ArrayList<TMapPoint> m_tmapPoint = new ArrayList<TMapPoint>();
    private ArrayList<String> mArrayMarkerID = new ArrayList<String>();
    private ArrayList<MapPoint> m_mapPoint = new ArrayList<MapPoint>();
    private ArrayList<NaviSearchList> naviSearchLists = new ArrayList<NaviSearchList>();
    private MapPoint mapPoint = new MapPoint();
    private BottomSheetDialog bottomSheetDialog;
    LocationManager lm = null;

    private String mTitle = null;
    private double mLat = 0;
    private double mLon = 0;
    private String pCategory = null;
    private String pTime = null;
    private String pTelNum = null;
    private String addr = null;
    String[] Categorize;

    TMapData tmapdata = new TMapData();

    String[] CategoryList;
    ArrayList<Category> arraylist = new ArrayList<Category>();

    public static MapPage newInstance(String title, double lat, double lon, String category, String time, String telNo) {
        MapPage fragment = new MapPage();
        Bundle args = new Bundle();
        args.putString("Title", title);
        args.putDouble("Lat", lat);
        args.putDouble("Lon", lon);
        args.putString("Category", category);
        args.putString("Time", time);
        args.putString("TelNum", telNo);

        Log.w("arg param", "" + args.getString("Title"));
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        mContext = getActivity();
        CategoryList = new String[]{"관광정보", "자전거", "숙박시설", "음식점"};

        View view = inflater.inflate(R.layout.map_page, container, false);

        LinearLayout linearLayout = (LinearLayout) view.findViewById(R.id.map);

        permissionManager = new PermissionManager(getActivity()); // 권한요청 관리자
        tmapview = new TMapView(mContext);

        getCurrentLocation();

        linearLayout.addView(tmapview);

        tmapview.setSKTMapApiKey(mApiKey);

        /* 현재 보는 방향 */
        tmapview.setCompassMode(false);

        /* 현위치 아이콘표시 */
        tmapview.setIconVisibility(true);

        /* 줌레벨 */
        tmapview.setZoomLevel(15);
        tmapview.setMapType(TMapView.MAPTYPE_STANDARD);
        tmapview.setLanguage(TMapView.LANGUAGE_KOREAN);

        Log.w("getArgument", "" + getArguments());

        if (getArguments() != null) {
            mTitle = getArguments().getString("Title");
            mLat = getArguments().getDouble("Lat");
            mLon = getArguments().getDouble("Lon");
            pCategory = getArguments().getString("Category");
            pTime = getArguments().getString("Time");
            pTelNum = getArguments().getString("TelNum");

            Categorize = pCategory.split("\\s");

            if (pTime == null && pTelNum == null)
                addNaviSearchList(new NaviSearchList(mTitle, mLat, mLon, pCategory));
            else
                resultLocation(mTitle, mLat, mLon);

        }

        /*  화면중심을 단말의 현재위치로 이동 */
        tmapview.setTrackingMode(false);
        tmapview.setSightVisible(false);


        // 풍선 클릭시 할 행동입니다
        tmapview.setOnCalloutRightButtonClickListener(new TMapView.OnCalloutRightButtonClickCallback() {
            @Override
            public void onCalloutRightButton(TMapMarkerItem markerItem) {
                tmapdata.reverseGeocoding(mLat, mLon, "A10", new TMapData.reverseGeocodingListenerCallback() {
                    @Override
                    public void onReverseGeocoding(TMapAddressInfo addressInfo) {

                        addr = addressInfo.strFullAddress;

                        int comma_count = 0;
                        int end_point = -1;
                        int end_point1 = -1;
                        while (comma_count != 2) {
                            for (int i = 0; i < addr.length(); i++) {
                                if (addr.charAt(i) == ',' && comma_count == 1) {
                                    end_point1 = i;
                                    comma_count++;
                                    break;
                                }
                                if (addr.charAt(i) == ',' && comma_count == 0) {
                                    comma_count++;
                                    end_point = i;
                                }

                            }
                        }
                        String addr1 = addr.substring(end_point + 1, end_point1);
                        String addr2 = addr.substring(end_point1 + 1, addr.length());

                        bottomSheetDialog = new BottomSheetDialog();
                        bottomSheetDialog = BottomSheetDialog.getInstance(mTitle, pCategory, addr1, addr2, pTime, pTelNum, mLat, mLon);
                        bottomSheetDialog.show(getChildFragmentManager(), "bottomSheet");

                    }
                });
            }
        });

        return view;
    }

    public void getCurrentLocation() {
        if (Build.VERSION.SDK_INT >= 23) {
            // 권한 요청 ( 요청 결과는 activity 의 onRequestPermissionsResult 함수로 넘어온다. )
            // 따라서 이 클래스를 맴버변수로 선언하고 onRequestPermissionsResult 함수에서
            // 이 클래스의 setResponse 함수를 호출해줘야 한다.
            // (requestCode = alPermissionListener 의 Index, 결과가 오면 alPermissionListener.get(requestCode) 에게 결과 전달함)
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);

        }
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w("LOG", "위치정보 접근 권한이 필요합니다.");

        } else {
//            tmapgps.OpenGps();
            lm = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
            tmapgps = new TMapGpsManager(mContext);

            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, // 등록할 위치제공자(실내에선 NETWORK_PROVIDER 권장)
                    1000, // 통지사이의 최소 시간간격 (miliSecond)
                    1, // 통지사이의 최소 변경거리 (m)
                    locationListener);
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, // 등록할 위치제공자
                    1000, // 통지사이의 최소 시간간격 (miliSecond)
                    1, // 통지사이의 최소 변경거리 (m)
                    locationListener);

            tmapgps.setMinTime(1000);
            tmapgps.setMinDistance(5);
            tmapgps.setProvider(tmapgps.GPS_PROVIDER);
            tmapgps.OpenGps();
            tmapgps.setProvider(tmapgps.NETWORK_PROVIDER);
            tmapgps.OpenGps();
            Log.w("t map gps getLocation", "" + lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER));
        }
    }

    public void addNaviSearchList (NaviSearchList naviSearchList) {
        naviSearchLists.add(naviSearchList);
        Log.w("navi search list size", "" + naviSearchLists.size());
        //poi_dot은 지도에 꼽을 빨간 핀 이미지입니다
        for (int i = 0; i < naviSearchLists.size(); i++) {
            MarkerCotegory markerCotegory = new MarkerCotegory(mContext, naviSearchLists.get(i).getMode());
            TMapMarkerItem item1 = new TMapMarkerItem();
            Bitmap bitmap = markerCotegory.BitmapMarker();

            TMapPoint point = new TMapPoint(naviSearchLists.get(i).getLat(), naviSearchLists.get(i).getLon());
            item1.setTMapPoint(point);
            item1.setName(naviSearchLists.get(i).getTitle());
            item1.setVisible(item1.VISIBLE);

            item1.setIcon(bitmap);

            String strID = String.format("pmarker%d", mMarkerID++);

            tmapview.addMarkerItem(strID, item1);
            mArrayMarkerID.add(strID);
        }
    }

    public double getCurrentLatitude () {
        double currentLat = 0;
        if (Build.VERSION.SDK_INT >= 23) {
            // 권한 요청 ( 요청 결과는 activity 의 onRequestPermissionsResult 함수로 넘어온다. )
            // 따라서 이 클래스를 맴버변수로 선언하고 onRequestPermissionsResult 함수에서
            // 이 클래스의 setResponse 함수를 호출해줘야 한다.
            // (requestCode = alPermissionListener 의 Index, 결과가 오면 alPermissionListener.get(requestCode) 에게 결과 전달함)
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);

        }
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w("LOG", "위치정보 접근 권한이 필요합니다.");

        } else {
            currentLat =  Objects.requireNonNull(lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)).getLatitude();
        }
        return currentLat;
    }

    public double getCurrentLongitude () {
        double currentLon = 0;
        if (Build.VERSION.SDK_INT >= 23) {
            // 권한 요청 ( 요청 결과는 activity 의 onRequestPermissionsResult 함수로 넘어온다. )
            // 따라서 이 클래스를 맴버변수로 선언하고 onRequestPermissionsResult 함수에서
            // 이 클래스의 setResponse 함수를 호출해줘야 한다.
            // (requestCode = alPermissionListener 의 Index, 결과가 오면 alPermissionListener.get(requestCode) 에게 결과 전달함)
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 0);

        }
        if (ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(getActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            Log.w("LOG", "위치정보 접근 권한이 필요합니다.");

        } else {
            currentLon =  Objects.requireNonNull(lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)).getLongitude();
        }
        return currentLon;
    }

    public void resultLocation(String title, double lat, double lon) {

        mapPoint = new MapPoint(title, lat, lon);
        String addr = null;
        if(tmapview != null)
            tmapview.removeAllMarkerItem();

        addPoint(new MapPoint(title, lat, lon));
        showMarkerPoint();

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        permissionManager.setResponse(requestCode, grantResults); // 권한요청 관리자에게 결과 전달
    }

    private final LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {
            if (location != null) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                String provider = location.getProvider();   //위치제공자
                tmapview.setLocationPoint(longitude, latitude);
                if (getArguments() == null)
                    tmapview.setCenterPoint(longitude, latitude);
                else
                    tmapview.setCenterPoint(mLon, mLat);
                Log.d("TmapTest", "" + longitude + "," + latitude + "," + provider);
                //Gps 위치제공자에 의한 위치변화. 오차범위가 좁다.
                //Network 위치제공자에 의한 위치변화
                //Network 위치는 Gps에 비해 정확도가 많이 떨어진다.
            }
        }

        @Override
        public void onStatusChanged(String s, int i, Bundle bundle) {
        }

        @Override
        public void onProviderEnabled(String s) {
        }

        @Override
        public void onProviderDisabled(String s) {
        }
    };

    @Override
    public void onLocationChange(Location location) {
        if (m_bTrackingMode) {
            tmapview.setLocationPoint(location.getLongitude(), location.getLatitude());
        }
    }


    public void addPoint(MapPoint mapPoints) {
        m_mapPoint.add(mapPoints);
    }


    public void showMarkerPoint() {// 마커 찍는거 빨간색 포인트.

        MarkerCotegory markerCotegory = new MarkerCotegory(mContext, Categorize[1]);
        for (int i = 0; i < m_mapPoint.size(); i++) {
            TMapPoint point = new TMapPoint(m_mapPoint.get(i).getLatitude(),
                    m_mapPoint.get(i).getLongitude());

            TMapMarkerItem item1 = new TMapMarkerItem();
            Bitmap bitmap = markerCotegory.BitmapMarker();

            //poi_dot은 지도에 꼽을 빨간 핀 이미지입니다

            item1.setTMapPoint(point);
            item1.setName(m_mapPoint.get(i).getName());
            item1.setVisible(item1.VISIBLE);

            item1.setIcon(bitmap);


            // 풍선뷰 안의 항목에 글을 지정합니다.
            item1.setCalloutTitle(m_mapPoint.get(i).getName());
            item1.setCalloutSubTitle(pCategory);
            item1.setCanShowCallout(true);
            item1.setAutoCalloutVisible(true);

            Bitmap bitmap_i = null;
            bitmap_i = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.i_go);

            item1.setCalloutRightButtonImage(bitmap_i);

            String strID = String.format("pmarker%d", mMarkerID++);

            tmapview.addMarkerItem(strID, item1);
            mArrayMarkerID.add(strID);
        }
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

}
