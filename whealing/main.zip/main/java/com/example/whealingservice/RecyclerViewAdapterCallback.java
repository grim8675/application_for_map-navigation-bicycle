package com.example.whealingservice;

public interface RecyclerViewAdapterCallback {
    void SelectSearchItem(int position);
}
