package com.example.whealingservice.search;

public class TMapSearchInfo {
    private SearchPoiInfo searchPoiInfo;

    public SearchPoiInfo getSearchPoiInfo() {
        return searchPoiInfo;
    }

    public void setSearchPoiInfo(SearchPoiInfo searchPoiInfo) {
        this.searchPoiInfo = searchPoiInfo;
    }
}
