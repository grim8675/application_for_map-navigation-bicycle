package com.example.whealingservice;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class MarkerCotegory {
    Context mContext;
    private String category;

    public MarkerCotegory (Context context, String category) {
        this.category = category;
        mContext = context;
    }

    public void setCategory (String category) {
        this.category = category;
    }

    public Bitmap BitmapMarker () {
        switch (this.category) {
            case "START":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker_start);
            case "MIDDLE1":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker_middle);
            case "FINISH":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker_finish);
            case "교육기관":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker1);
            case "관광명소":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker2);
            case "음식점":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker3);
            case "술집":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker3);
            case "교통시설":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker4);
            case "의료시설":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker5);
            case "기타의료시설":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker5);
            case "생활서비스":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker6);
            case "숙박":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker7);
            case "카페":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker8);
            case "문화생활시설":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker9);
            case "대형유통점":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker11);
            case "쇼핑기타":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker11);
            case "의료직물":
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker11);
            default:
                return BitmapFactory.decodeResource(mContext.getResources(), R.drawable.marker10);

        }
    }
}
