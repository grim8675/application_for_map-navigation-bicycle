package com.example.whealingservice;

import com.example.whealingservice.search.DetailInfo;
import com.example.whealingservice.search.Poi;
import com.example.whealingservice.search.TMapSearchInfo;
import com.example.whealingservice.search.SearchPoiInfo;
import com.google.gson.Gson;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class AutoCompleteParse extends AsyncTask<String, Void, ArrayList<SearchEntity>>
{
    private final String TMAP_API_KEY = "e2a8e309-be72-4e1e-941f-0ef0b77e4317";
    private final int SEARCH_COUNT = 30;  // minimum is 20
    private ArrayList<SearchEntity> mListData;
    private RecyclerViewAdapter mAdapter;

    public AutoCompleteParse(RecyclerViewAdapter adapter) {
        this.mAdapter = adapter;
        mListData = new ArrayList<SearchEntity>();
    }

    @Override
    protected ArrayList<SearchEntity> doInBackground(String... word) {
        return getAutoComplete(word[0]);
    }

    @Override
    protected void onPostExecute(ArrayList<SearchEntity> autoCompleteItems) {
        mAdapter.setData(autoCompleteItems);
        mAdapter.notifyDataSetChanged();
    }

    public ArrayList<SearchEntity> getAutoComplete(String word){

        try{
            String encodeWord = URLEncoder.encode(word, "UTF-8");
            URL acUrl = new URL(
                    "https://apis.openapi.sk.com/tmap/pois?areaLMCode=&centerLon=&centerLat=&" +
                            "count=" + SEARCH_COUNT + "&page=1&reqCoordType=&" + "" +
                            "searchKeyword=" + encodeWord + "&callback=&areaLLCode=&multiPoint=&searchtypCd=&radius=&searchType=&resCoordType=WGS84GEO&version=1&"
            );

            HttpURLConnection acConn = (HttpURLConnection)acUrl.openConnection();
            acConn.setRequestProperty("Accept", "application/json");
            acConn.setRequestProperty("appKey", TMAP_API_KEY);

            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    acConn.getInputStream()));

            String line = reader.readLine();
            if(line == null){
                mListData.clear();
                return mListData;
            }


            reader.close();

            mListData.clear();

            TMapSearchInfo searchPoiInfo = new Gson().fromJson(line, TMapSearchInfo.class);

            ArrayList<Poi> poi =  searchPoiInfo.getSearchPoiInfo().getPois().getPoi();

            for(int i =0; i < poi.size(); i++){
                String fullAddr = poi.get(i).getUpperAddrName() + " " + poi.get(i).getMiddleAddrName() +
                        " " + poi.get(i).getLowerAddrName() + " " + poi.get(i).getDetailAddrName();
                double Lat = Double.parseDouble(poi.get(i).getFrontLat());
                double Lon = Double.parseDouble(poi.get(i).getFrontLon());
                String category = poi.get(i).getUpperBizName() + " " + poi.get(i).getMiddleBizName() + " " + poi.get(i).getLowerBizName() + " " + poi.get(i).getDetailBizName();
                String telNo = poi.get(i).getTelNo();
                String time = "10:00 ~ 21:00";      //영업시간 수정해야함

                mListData.add(new SearchEntity(poi.get(i).getName(), fullAddr, Lat, Lon, category, time, telNo));
            }

        }catch (IOException e){
            e.printStackTrace();
        }
        Log.w("AutoComplete List Data ", "" + mListData);
        return mListData;
    }
}
