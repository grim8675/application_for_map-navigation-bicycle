package com.example.whealingservice.Navigation;

import java.util.ArrayList;

public class NaviSearchLists {

    private ArrayList<NaviSearchList> naviSearchLists = null;

    public ArrayList<NaviSearchList> getNaviSearchList() {
        return naviSearchLists;
    }

    public void setNaviSearchList(ArrayList<NaviSearchList> navisearchlist) {
        this.naviSearchLists = navisearchlist;
    }

}
