package com.example.whealingservice;


public class SearchEntity {
    private String title;
    private String address;
    private double Lat;
    private double Lon;

    private String category;
    private String addr;
    private String time;
    private String telNo;

    public SearchEntity(String title, String address, double Lat, double Lon, String category, String time, String telNo) {
        this.title = title;
        this.address = address;
        this.Lat = Lat;
        this.Lon = Lon;
        this.category = category;
//        this.addr = addr;
        this.time = time;
        this.telNo = telNo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public double getLat() {
        return Lat;
    }

    public void setLat(double lat) {
        Lat = lat;
    }

    public double getLon() {
        return Lon;
    }

    public void setLon(double lon) {
        Lon = lon;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }
}
