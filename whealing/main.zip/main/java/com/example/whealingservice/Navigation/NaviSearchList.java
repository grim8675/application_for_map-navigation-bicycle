package com.example.whealingservice.Navigation;



public class NaviSearchList{

    private String title;
    private double lat;
    private double lon;
    private String mode;

    public NaviSearchList (String title, double lat, double lon, String mode) {
        this.title = title;
        this.lat = lat;
        this.lon = lon;
        this.mode =  mode;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLon() {
        return lon;
    }

    public void setLon(double lon) {
        this.lon = lon;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }
}
