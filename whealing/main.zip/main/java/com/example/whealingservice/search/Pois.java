package com.example.whealingservice.search;

import java.util.ArrayList;

public class Pois {
    private ArrayList<Poi> poi = null;

    public ArrayList<Poi> getPoi() {
        return poi;
    }

    public void setPoi(ArrayList<Poi> poi) {
        this.poi = poi;
    }
}
